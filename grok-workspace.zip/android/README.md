# Steward (Android)

Minimal personal background assistant.

- Core loop: `app/src/main/java/app/steward/Assistant.kt`
- Tasks / settings: `app/src/main/assets/config.json`

Enable the Accessibility service from the app screen. The service only keeps the local loop alive — it does not read or control other apps.

Internet permission is declared for later use. This build does not call any API.

GitHub Actions (`.github/workflows/build-debug-apk.yml`) runs `gradle assembleDebug` and uploads the APK.
