package app.steward

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.util.TypedValue
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

/**
 * Core loop + launcher. Tasks come from assets/config.json.
 * Accessibility keeps the loop alive; it does not inspect or drive other apps.
 */
class Assistant : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val tick = Runnable { pass() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.i(TAG, "connected — starting local loop")
        handler.post(tick)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Local task runner only. Window content is not retrieved.
    }

    override fun onInterrupt() {
        Log.i(TAG, "interrupted")
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun pass() {
        val config = loadConfig()
        val delay = config.intervalMs.coerceAtLeast(1_000L)
        if (!config.enabled) {
            Log.i(TAG, "config.enabled=false — skipping")
        } else {
            for (task in config.tasks) {
                if (!task.enabled) continue
                when (task.kind) {
                    "wait" -> Log.i(TAG, "wait ${task.durationMs}ms — ${task.message}")
                    "note" -> Log.i(TAG, "note: ${task.message}")
                    else -> Log.i(TAG, task.message.ifBlank { "log" })
                }
            }
        }
        handler.postDelayed(tick, delay)
    }

    private fun loadConfig(): Config {
        return try {
            val raw = assets.open("config.json").bufferedReader().use { it.readText() }
            parseConfig(raw)
        } catch (error: Exception) {
            Log.w(TAG, "config read failed, using defaults", error)
            Config(enabled = true, intervalMs = 15_000L, tasks = emptyList())
        }
    }

    companion object {
        const val TAG = "Steward"
    }
}

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(24)

        val title = TextView(this).apply {
            text = "Steward"
            setTextColor(Color.parseColor("#F3EFE6"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
        }
        val body = TextView(this).apply {
            text = "Enable the Accessibility service to run the background loop. Edit assets/config.json to add tasks. No API keys are required."
            setTextColor(Color.parseColor("#9C9588"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setPadding(0, dp(12), 0, dp(24))
        }
        val button = Button(this).apply {
            text = "Open accessibility settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0C0B0A"))
            setPadding(pad, pad, pad, pad)
            addView(title)
            addView(body)
            addView(button)
        }
        setContentView(ScrollView(this).apply { addView(column) })
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics,
        ).toInt()
}

data class Config(
    val enabled: Boolean,
    val intervalMs: Long,
    val tasks: List<Task>,
)

data class Task(
    val id: String,
    val kind: String,
    val message: String,
    val durationMs: Long,
    val enabled: Boolean,
)

fun parseConfig(raw: String): Config {
    val root = JSONObject(raw)
    val list = mutableListOf<Task>()
    val tasks: JSONArray = root.optJSONArray("tasks") ?: JSONArray()
    for (index in 0 until tasks.length()) {
        val item = tasks.optJSONObject(index) ?: continue
        list += Task(
            id = item.optString("id", "task-$index"),
            kind = item.optString("kind", "log"),
            message = item.optString("message", ""),
            durationMs = item.optLong("durationMs", 0L),
            enabled = item.optBoolean("enabled", true),
        )
    }
    return Config(
        enabled = root.optBoolean("enabled", true),
        intervalMs = root.optLong("intervalMs", 15_000L),
        tasks = list,
    )
}
