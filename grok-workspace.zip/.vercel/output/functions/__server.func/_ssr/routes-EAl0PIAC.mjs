import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, i as RotateCcw, n as Trash2, o as CirclePlay, r as Terminal, s as CirclePause } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-EAl0PIAC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Badge({ className, tone = "muted", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium tracking-wide", tone === "live" && "border-live/30 bg-live/10 text-live", tone === "warn" && "border-warn/30 bg-warn/10 text-warn", tone === "muted" && "border-line bg-raised text-muted", className),
		children
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[var(--radius-sm)] font-medium transition-[opacity,transform,background-color,color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-smooth-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 disabled:pointer-events-none disabled:opacity-40 active:scale-[0.98]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:opacity-90",
			secondary: "border border-line bg-raised text-fg hover:bg-surface",
			ghost: "text-muted hover:bg-raised hover:text-fg",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			sm: "h-9 px-3 text-sm",
			md: "h-11 px-4 text-sm",
			lg: "h-12 px-5 text-base"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		ref,
		...props
	});
});
Button.displayName = "Button";
var TASK_KINDS = [
	"log",
	"wait",
	"note"
];
var DEFAULT_CONFIG = {
	enabled: true,
	intervalMs: 8e3,
	tasks: [
		{
			id: "heartbeat",
			kind: "log",
			message: "Steward heartbeat",
			durationMs: 0,
			enabled: true
		},
		{
			id: "brief-pause",
			kind: "wait",
			message: "Settle for two seconds",
			durationMs: 2e3,
			enabled: true
		},
		{
			id: "inbox-note",
			kind: "note",
			message: "Add your own tasks in Config. No API keys required.",
			durationMs: 0,
			enabled: true
		}
	]
};
function newTaskId() {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return crypto.randomUUID();
	return `task-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function parseConfig(raw) {
	const parsed = JSON.parse(raw);
	const intervalMs = Number(parsed.intervalMs);
	const tasks = Array.isArray(parsed.tasks) ? parsed.tasks : [];
	return {
		enabled: parsed.enabled !== false,
		intervalMs: Number.isFinite(intervalMs) ? Math.max(1e3, intervalMs) : 8e3,
		tasks: tasks.map((task, index) => {
			const item = task;
			const kind = TASK_KINDS.includes(item.kind) ? item.kind : "log";
			const durationMs = Number(item.durationMs);
			return {
				id: typeof item.id === "string" && item.id ? item.id : `task-${index + 1}`,
				kind,
				message: typeof item.message === "string" ? item.message : "",
				durationMs: Number.isFinite(durationMs) ? Math.max(0, durationMs) : 0,
				enabled: item.enabled !== false
			};
		})
	};
}
function formatConfig(config) {
	return `${JSON.stringify(config, null, 2)}\n`;
}
var noopStorage = {
	getItem: () => null,
	setItem: () => void 0,
	removeItem: () => void 0
};
var MAX_LOG = 80;
var useAssistant = create()(persist((set, get) => ({
	config: DEFAULT_CONFIG,
	running: false,
	ticks: 0,
	lastTickAt: null,
	lastTaskLabel: "Idle",
	log: [],
	configText: formatConfig(DEFAULT_CONFIG),
	configError: null,
	start: () => set({ running: true }),
	stop: () => set({
		running: false,
		lastTaskLabel: "Paused"
	}),
	toggleTask: (id) => {
		const config = {
			...get().config,
			tasks: get().config.tasks.map((task) => task.id === id ? {
				...task,
				enabled: !task.enabled
			} : task)
		};
		set({
			config,
			configText: formatConfig(config),
			configError: null
		});
	},
	addTask: (task) => {
		const config = {
			...get().config,
			tasks: [...get().config.tasks, {
				...task,
				id: newTaskId()
			}]
		};
		set({
			config,
			configText: formatConfig(config),
			configError: null
		});
	},
	removeTask: (id) => {
		const config = {
			...get().config,
			tasks: get().config.tasks.filter((task) => task.id !== id)
		};
		set({
			config,
			configText: formatConfig(config),
			configError: null
		});
	},
	setIntervalMs: (ms) => {
		const config = {
			...get().config,
			intervalMs: Math.max(1e3, ms)
		};
		set({
			config,
			configText: formatConfig(config),
			configError: null
		});
	},
	setConfigText: (text) => set({
		configText: text,
		configError: null
	}),
	applyConfigText: () => {
		try {
			const config = parseConfig(get().configText);
			set({
				config,
				configText: formatConfig(config),
				configError: null
			});
		} catch (error) {
			set({ configError: error instanceof Error ? error.message : "Could not parse config JSON." });
		}
	},
	resetConfig: () => set({
		config: DEFAULT_CONFIG,
		configText: formatConfig(DEFAULT_CONFIG),
		configError: null
	}),
	clearLog: () => set({ log: [] }),
	appendLog: (entry) => set((state) => ({ log: [{
		id: newTaskId(),
		at: Date.now(),
		...entry
	}, ...state.log].slice(0, MAX_LOG) }))
}), {
	name: "steward-assistant",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? noopStorage : localStorage),
	partialize: (state) => ({
		config: state.config,
		configText: state.configText
	})
}));
async function runTick() {
	const { config, appendLog } = useAssistant.getState();
	if (!config.enabled) {
		appendLog({
			taskId: null,
			kind: "system",
			text: "Config enabled is false — skipping this pass."
		});
		useAssistant.setState({
			ticks: useAssistant.getState().ticks + 1,
			lastTickAt: Date.now(),
			lastTaskLabel: "Skipped"
		});
		return;
	}
	const enabledTasks = config.tasks.filter((task) => task.enabled);
	if (enabledTasks.length === 0) appendLog({
		taskId: null,
		kind: "system",
		text: "No enabled tasks in config."
	});
	for (const task of enabledTasks) {
		useAssistant.setState({ lastTaskLabel: `${task.kind} · ${task.id}` });
		switch (task.kind) {
			case "wait": {
				const ms = Math.min(task.durationMs || 1e3, 4e3);
				appendLog({
					taskId: task.id,
					kind: "wait",
					text: `Wait ${ms}ms — ${task.message || "pause"}`
				});
				await sleep(ms);
				break;
			}
			case "note":
				appendLog({
					taskId: task.id,
					kind: "note",
					text: task.message || "Empty note"
				});
				break;
			default: appendLog({
				taskId: task.id,
				kind: "log",
				text: task.message || "log"
			});
		}
	}
	useAssistant.setState({
		ticks: useAssistant.getState().ticks + 1,
		lastTickAt: Date.now()
	});
}
function sleep(ms) {
	return new Promise((resolve) => {
		window.setTimeout(resolve, ms);
	});
}
var TABS = [
	"Console",
	"Config",
	"Android"
];
function formatTime(ts) {
	if (!ts) return "—";
	return new Date(ts).toLocaleTimeString([], {
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
}
function StewardApp() {
	const running = useAssistant((s) => s.running);
	const config = useAssistant((s) => s.config);
	const ticks = useAssistant((s) => s.ticks);
	const lastTickAt = useAssistant((s) => s.lastTickAt);
	const lastTaskLabel = useAssistant((s) => s.lastTaskLabel);
	const start = useAssistant((s) => s.start);
	const stop = useAssistant((s) => s.stop);
	const busy = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		useAssistant.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		let cancelled = false;
		const loop = async () => {
			if (busy.current) return;
			busy.current = true;
			try {
				await runTick();
			} finally {
				busy.current = false;
			}
		};
		loop();
		const id = window.setInterval(() => {
			if (cancelled) return;
			loop();
		}, config.intervalMs);
		return () => {
			cancelled = true;
			window.clearInterval(id);
		};
	}, [running, config.intervalMs]);
	const [tab, setTab] = (0, import_react.useState)("Console");
	const enabledCount = config.tasks.filter((t) => t.enabled).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-[0.22em] text-muted uppercase",
								children: "Personal assistant"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-4xl font-medium tracking-[-0.03em] text-fg sm:text-5xl",
								children: "Steward"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-md text-sm leading-relaxed text-muted",
								children: "A local background loop. Edit the config, start the steward, and it will carry out whatever tasks you leave for it. No keys, no remote host."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							tone: running ? "live" : "muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full bg-current", running && "steward-pulse") }), running ? "Running" : "Paused"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: running ? "secondary" : "primary",
							onClick: () => running ? stop() : start(),
							children: [running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlay, { className: "size-4" }), running ? "Pause loop" : "Start loop"]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Interval",
							value: `${config.intervalMs / 1e3}s`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Enabled tasks",
							value: String(enabledCount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Ticks",
							value: String(ticks)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Last pass",
							value: formatTime(lastTickAt)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs text-faint",
					children: ["Active step · ", lastTaskLabel]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-1 rounded-[var(--radius-md)] border border-line bg-surface p-1",
					children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setTab(item),
						className: cn("h-10 flex-1 rounded-[var(--radius-sm)] text-sm font-medium transition-colors duration-[var(--motion-quick)]", tab === item ? "bg-raised text-fg" : "text-muted hover:text-fg"),
						children: item
					}, item))
				}),
				tab === "Console" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsolePanel, {}),
				tab === "Config" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfigPanel, {}),
				tab === "Android" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AndroidPanel, {})
			]
		})
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[var(--radius-lg)] border border-line bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-wide text-faint uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-mono text-lg tabular-nums text-fg",
			children: value
		})]
	});
}
function ConsolePanel() {
	const tasks = useAssistant((s) => s.config.tasks);
	const log = useAssistant((s) => s.log);
	const toggleTask = useAssistant((s) => s.toggleTask);
	const removeTask = useAssistant((s) => s.removeTask);
	const addTask = useAssistant((s) => s.addTask);
	const clearLog = useAssistant((s) => s.clearLog);
	const [kind, setKind] = (0, import_react.useState)("log");
	const [message, setMessage] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-[var(--radius-xl)] border border-line bg-surface p-4 sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium text-fg",
						children: "Task queue"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-faint",
						children: [tasks.length, " defined"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: tasks.map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-3 rounded-[var(--radius-md)] border border-line bg-raised p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": task.enabled ? "Disable task" : "Enable task",
								onClick: () => toggleTask(task.id),
								className: cn("mt-0.5 size-11 shrink-0 rounded-[var(--radius-sm)] border text-xs font-medium", task.enabled ? "border-live/40 bg-live/10 text-live" : "border-line bg-surface text-faint"),
								children: task.kind
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-mono text-xs text-faint",
										children: task.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-fg",
										children: task.message || "—"
									}),
									task.kind === "wait" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted",
										children: [task.durationMs, "ms"]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "Remove task",
								onClick: () => removeTask(task.id),
								className: "mt-0.5 grid size-11 place-items-center rounded-[var(--radius-sm)] text-faint hover:bg-bg hover:text-danger",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
							})
						]
					}, task.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					className: "mt-4 space-y-3 border-t border-line pt-4",
					onSubmit: (event) => {
						event.preventDefault();
						const trimmed = message.trim();
						if (!trimmed) return;
						addTask({
							kind,
							message: trimmed,
							durationMs: kind === "wait" ? 1500 : 0,
							enabled: true
						});
						setMessage("");
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: kind,
								onChange: (event) => setKind(event.target.value),
								className: "h-11 rounded-[var(--radius-sm)] border border-line bg-raised px-3 text-sm text-fg",
								children: TASK_KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: item
								}, item))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: message,
								onChange: (event) => setMessage(event.target.value),
								placeholder: "Task message",
								className: "h-11 min-w-0 flex-1 rounded-[var(--radius-sm)] border border-line bg-raised px-3 text-sm text-fg placeholder:text-faint"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								size: "md",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add"]
							})
						]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "rounded-[var(--radius-xl)] border border-line bg-surface p-4 sm:p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "flex items-center gap-2 text-sm font-medium text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Terminal, { className: "size-4 text-muted" }), "Loop log"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: clearLog,
					children: "Clear"
				})]
			}), log.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-12 text-center text-sm text-muted",
				children: "Start the loop to see tasks run here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "max-h-[28rem] space-y-2 overflow-auto pr-1",
				children: log.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-[var(--radius-sm)] border border-line bg-raised px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[11px] tracking-wide text-live uppercase",
							children: entry.kind
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[11px] tabular-nums text-faint",
							children: formatTime(entry.at)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-snug text-fg",
						children: entry.text
					})]
				}, entry.id))
			})]
		})]
	});
}
function ConfigPanel() {
	const config = useAssistant((s) => s.config);
	const configText = useAssistant((s) => s.configText);
	const configError = useAssistant((s) => s.configError);
	const setConfigText = useAssistant((s) => s.setConfigText);
	const applyConfigText = useAssistant((s) => s.applyConfigText);
	const resetConfig = useAssistant((s) => s.resetConfig);
	const setIntervalMs = useAssistant((s) => s.setIntervalMs);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-[var(--radius-xl)] border border-line bg-surface p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium text-fg",
					children: "Command file"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						"Same schema as the Android ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: "config.json"
						}),
						". Kinds: log, wait, note."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						size: "sm",
						onClick: applyConfigText,
						children: "Apply JSON"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: resetConfig,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-3.5" }), "Reset"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-4 flex items-center justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "Loop interval"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: config.intervalMs,
					onChange: (event) => setIntervalMs(Number(event.target.value)),
					className: "h-11 rounded-[var(--radius-sm)] border border-line bg-raised px-3 text-sm text-fg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 4e3,
							children: "4 seconds"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 8e3,
							children: "8 seconds"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 15e3,
							children: "15 seconds"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: 3e4,
							children: "30 seconds"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				value: configText,
				onChange: (event) => setConfigText(event.target.value),
				spellCheck: false,
				className: "min-h-72 w-full rounded-[var(--radius-md)] border border-line bg-bg p-4 font-mono text-sm leading-relaxed text-fg"
			}),
			configError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-danger",
				children: configError
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-faint",
				children: "Paste this JSON into the Android app assets file when you are ready to run on a device."
			})
		]
	});
}
function AndroidPanel() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-4 rounded-[var(--radius-xl)] border border-line bg-surface p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium tracking-[-0.03em]",
				children: "Native companion"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm leading-relaxed text-muted",
				children: "This preview runs the same loop in the browser. The Kotlin project is a bare framework: one core file, one config file, internet + accessibility permissions declared, and a GitHub Action that builds a debug APK."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-[var(--radius-lg)] border border-line bg-raised p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.18em] text-warn uppercase",
					children: "About the 502"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-fg",
					children: "You do not need API keys. The Bad Gateway / Host Error was the preview relay being down — your browser and Cloudflare were fine, the app host was not. Steward never calls that host. Nothing to configure."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "space-y-3 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-fg",
							children: "1. Core loop — "
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-accent",
							children: "Assistant.kt"
						}),
						" ",
						"reads ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-accent",
							children: "config.json"
						}),
						" ",
						"and walks enabled tasks on an interval."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "2. Permissions — "
					}), "INTERNET is declared for later network tasks. Accessibility is a connected stub so the service can stay alive; it does not read or tap other apps."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-fg",
							children: "3. APK — "
						}),
						"Push the repo to GitHub. The workflow",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-accent",
							children: ".github/workflows/build-debug-apk.yml"
						}),
						" ",
						"runs Gradle ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs",
							children: "assembleDebug"
						}),
						" ",
						"and uploads the APK."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-fg",
							children: "4. On device — "
						}),
						"Install the debug APK, open Steward, enable the accessibility service, then edit ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs",
							children: "config.json"
						}),
						" to add work."
					] })
				]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StewardApp, {});
}
//#endregion
export { Home as component };
