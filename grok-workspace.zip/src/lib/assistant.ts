import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export const TASK_KINDS = ["log", "wait", "note"] as const;
export type TaskKind = (typeof TASK_KINDS)[number];

export type Task = {
  id: string;
  kind: TaskKind;
  message: string;
  durationMs: number;
  enabled: boolean;
};

export type AssistantConfig = {
  enabled: boolean;
  intervalMs: number;
  tasks: Task[];
};

export type LogEntry = {
  id: string;
  at: number;
  taskId: string | null;
  kind: string;
  text: string;
};

export const DEFAULT_CONFIG: AssistantConfig = {
  enabled: true,
  intervalMs: 8000,
  tasks: [
    {
      id: "heartbeat",
      kind: "log",
      message: "Steward heartbeat",
      durationMs: 0,
      enabled: true,
    },
    {
      id: "brief-pause",
      kind: "wait",
      message: "Settle for two seconds",
      durationMs: 2000,
      enabled: true,
    },
    {
      id: "inbox-note",
      kind: "note",
      message: "Add your own tasks in Config. No API keys required.",
      durationMs: 0,
      enabled: true,
    },
  ],
};

export function newTaskId(): string {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return `task-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function parseConfig(raw: string): AssistantConfig {
  const parsed = JSON.parse(raw) as Partial<AssistantConfig>;
  const intervalMs = Number(parsed.intervalMs);
  const tasks = Array.isArray(parsed.tasks) ? parsed.tasks : [];
  return {
    enabled: parsed.enabled !== false,
    intervalMs: Number.isFinite(intervalMs) ? Math.max(1000, intervalMs) : 8000,
    tasks: tasks.map((task, index) => {
      const item = task as Partial<Task>;
      const kind = TASK_KINDS.includes(item.kind as TaskKind)
        ? (item.kind as TaskKind)
        : "log";
      const durationMs = Number(item.durationMs);
      return {
        id: typeof item.id === "string" && item.id ? item.id : `task-${index + 1}`,
        kind,
        message: typeof item.message === "string" ? item.message : "",
        durationMs: Number.isFinite(durationMs) ? Math.max(0, durationMs) : 0,
        enabled: item.enabled !== false,
      };
    }),
  };
}

function formatConfig(config: AssistantConfig): string {
  return `${JSON.stringify(config, null, 2)}\n`;
}

const noopStorage = {
  getItem: () => null,
  setItem: () => undefined,
  removeItem: () => undefined,
};

type AssistantState = {
  config: AssistantConfig;
  running: boolean;
  ticks: number;
  lastTickAt: number | null;
  lastTaskLabel: string;
  log: LogEntry[];
  configText: string;
  configError: string | null;
  start: () => void;
  stop: () => void;
  toggleTask: (id: string) => void;
  addTask: (task: Omit<Task, "id">) => void;
  removeTask: (id: string) => void;
  setIntervalMs: (ms: number) => void;
  setConfigText: (text: string) => void;
  applyConfigText: () => void;
  resetConfig: () => void;
  clearLog: () => void;
  appendLog: (entry: Omit<LogEntry, "id" | "at">) => void;
};

const MAX_LOG = 80;

export const useAssistant = create<AssistantState>()(
  persist(
    (set, get) => ({
      config: DEFAULT_CONFIG,
      running: false,
      ticks: 0,
      lastTickAt: null,
      lastTaskLabel: "Idle",
      log: [],
      configText: formatConfig(DEFAULT_CONFIG),
      configError: null,
      start: () => set({ running: true }),
      stop: () => set({ running: false, lastTaskLabel: "Paused" }),
      toggleTask: (id) => {
        const config = {
          ...get().config,
          tasks: get().config.tasks.map((task) =>
            task.id === id ? { ...task, enabled: !task.enabled } : task,
          ),
        };
        set({ config, configText: formatConfig(config), configError: null });
      },
      addTask: (task) => {
        const config = {
          ...get().config,
          tasks: [...get().config.tasks, { ...task, id: newTaskId() }],
        };
        set({ config, configText: formatConfig(config), configError: null });
      },
      removeTask: (id) => {
        const config = {
          ...get().config,
          tasks: get().config.tasks.filter((task) => task.id !== id),
        };
        set({ config, configText: formatConfig(config), configError: null });
      },
      setIntervalMs: (ms) => {
        const config = { ...get().config, intervalMs: Math.max(1000, ms) };
        set({ config, configText: formatConfig(config), configError: null });
      },
      setConfigText: (text) => set({ configText: text, configError: null }),
      applyConfigText: () => {
        try {
          const config = parseConfig(get().configText);
          set({
            config,
            configText: formatConfig(config),
            configError: null,
          });
        } catch (error) {
          set({
            configError:
              error instanceof Error ? error.message : "Could not parse config JSON.",
          });
        }
      },
      resetConfig: () =>
        set({
          config: DEFAULT_CONFIG,
          configText: formatConfig(DEFAULT_CONFIG),
          configError: null,
        }),
      clearLog: () => set({ log: [] }),
      appendLog: (entry) =>
        set((state) => ({
          log: [
            {
              id: newTaskId(),
              at: Date.now(),
              ...entry,
            },
            ...state.log,
          ].slice(0, MAX_LOG),
        })),
    }),
    {
      name: "steward-assistant",
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? noopStorage : localStorage,
      ),
      partialize: (state) => ({
        config: state.config,
        configText: state.configText,
      }),
    },
  ),
);

export async function runTick(): Promise<void> {
  const { config, appendLog } = useAssistant.getState();
  if (!config.enabled) {
    appendLog({
      taskId: null,
      kind: "system",
      text: "Config enabled is false — skipping this pass.",
    });
    useAssistant.setState({
      ticks: useAssistant.getState().ticks + 1,
      lastTickAt: Date.now(),
      lastTaskLabel: "Skipped",
    });
    return;
  }

  const enabledTasks = config.tasks.filter((task) => task.enabled);
  if (enabledTasks.length === 0) {
    appendLog({
      taskId: null,
      kind: "system",
      text: "No enabled tasks in config.",
    });
  }

  for (const task of enabledTasks) {
    useAssistant.setState({ lastTaskLabel: `${task.kind} · ${task.id}` });
    switch (task.kind) {
      case "wait": {
        const ms = Math.min(task.durationMs || 1000, 4000);
        appendLog({
          taskId: task.id,
          kind: "wait",
          text: `Wait ${ms}ms — ${task.message || "pause"}`,
        });
        await sleep(ms);
        break;
      }
      case "note":
        appendLog({
          taskId: task.id,
          kind: "note",
          text: task.message || "Empty note",
        });
        break;
      default:
        appendLog({
          taskId: task.id,
          kind: "log",
          text: task.message || "log",
        });
    }
  }

  useAssistant.setState({
    ticks: useAssistant.getState().ticks + 1,
    lastTickAt: Date.now(),
  });
}

function sleep(ms: number) {
  return new Promise<void>((resolve) => {
    window.setTimeout(resolve, ms);
  });
}
