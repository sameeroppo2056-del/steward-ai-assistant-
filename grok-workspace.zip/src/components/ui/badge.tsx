import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "muted",
  children,
}: {
  className?: string;
  tone?: "muted" | "live" | "warn";
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium tracking-wide",
        tone === "live" && "border-live/30 bg-live/10 text-live",
        tone === "warn" && "border-warn/30 bg-warn/10 text-warn",
        tone === "muted" && "border-line bg-raised text-muted",
        className,
      )}
    >
      {children}
    </span>
  );
}
