import { useEffect, useRef, useState } from "react";
import {
  CirclePause,
  CirclePlay,
  Plus,
  RotateCcw,
  Trash2,
  Terminal,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  runTick,
  TASK_KINDS,
  useAssistant,
  type TaskKind,
} from "@/lib/assistant";
import { cn } from "@/lib/utils";

const TABS = ["Console", "Config", "Android"] as const;
type Tab = (typeof TABS)[number];

function formatTime(ts: number | null): string {
  if (!ts) return "—";
  return new Date(ts).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function StewardApp() {
  const running = useAssistant((s) => s.running);
  const config = useAssistant((s) => s.config);
  const ticks = useAssistant((s) => s.ticks);
  const lastTickAt = useAssistant((s) => s.lastTickAt);
  const lastTaskLabel = useAssistant((s) => s.lastTaskLabel);
  const start = useAssistant((s) => s.start);
  const stop = useAssistant((s) => s.stop);
  const busy = useRef(false);

  useEffect(() => {
    void useAssistant.persist.rehydrate();
  }, []);

  useEffect(() => {
    if (!running) return;
    let cancelled = false;

    const loop = async () => {
      if (busy.current) return;
      busy.current = true;
      try {
        await runTick();
      } finally {
        busy.current = false;
      }
    };

    void loop();
    const id = window.setInterval(() => {
      if (cancelled) return;
      void loop();
    }, config.intervalMs);

    return () => {
      cancelled = true;
      window.clearInterval(id);
    };
  }, [running, config.intervalMs]);

  const [tab, setTab] = useState<Tab>("Console");
  const enabledCount = config.tasks.filter((t) => t.enabled).length;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-10">
        <header className="flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between">
          <div className="space-y-3">
            <p className="text-xs font-medium tracking-[0.22em] text-muted uppercase">
              Personal assistant
            </p>
            <h1 className="font-display text-4xl font-medium tracking-[-0.03em] text-fg sm:text-5xl">
              Steward
            </h1>
            <p className="max-w-md text-sm leading-relaxed text-muted">
              A local background loop. Edit the config, start the steward, and
              it will carry out whatever tasks you leave for it. No keys, no
              remote host.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <Badge tone={running ? "live" : "muted"}>
              <span
                className={cn(
                  "size-1.5 rounded-full bg-current",
                  running && "steward-pulse",
                )}
              />
              {running ? "Running" : "Paused"}
            </Badge>
            <Button
              variant={running ? "secondary" : "primary"}
              onClick={() => (running ? stop() : start())}
            >
              {running ? (
                <CirclePause className="size-4" />
              ) : (
                <CirclePlay className="size-4" />
              )}
              {running ? "Pause loop" : "Start loop"}
            </Button>
          </div>
        </header>

        <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Interval" value={`${config.intervalMs / 1000}s`} />
          <Stat label="Enabled tasks" value={String(enabledCount)} />
          <Stat label="Ticks" value={String(ticks)} />
          <Stat label="Last pass" value={formatTime(lastTickAt)} />
        </section>

        <p className="font-mono text-xs text-faint">
          Active step · {lastTaskLabel}
        </p>

        <div className="flex gap-1 rounded-[var(--radius-md)] border border-line bg-surface p-1">
          {TABS.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setTab(item)}
              className={cn(
                "h-10 flex-1 rounded-[var(--radius-sm)] text-sm font-medium transition-colors duration-[var(--motion-quick)]",
                tab === item
                  ? "bg-raised text-fg"
                  : "text-muted hover:text-fg",
              )}
            >
              {item}
            </button>
          ))}
        </div>

        {tab === "Console" && <ConsolePanel />}
        {tab === "Config" && <ConfigPanel />}
        {tab === "Android" && <AndroidPanel />}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[var(--radius-lg)] border border-line bg-surface p-4">
      <p className="text-xs tracking-wide text-faint uppercase">{label}</p>
      <p className="mt-2 font-mono text-lg tabular-nums text-fg">{value}</p>
    </div>
  );
}

function ConsolePanel() {
  const tasks = useAssistant((s) => s.config.tasks);
  const log = useAssistant((s) => s.log);
  const toggleTask = useAssistant((s) => s.toggleTask);
  const removeTask = useAssistant((s) => s.removeTask);
  const addTask = useAssistant((s) => s.addTask);
  const clearLog = useAssistant((s) => s.clearLog);
  const [kind, setKind] = useState<TaskKind>("log");
  const [message, setMessage] = useState("");

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]">
      <section className="rounded-[var(--radius-xl)] border border-line bg-surface p-4 sm:p-5">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="text-sm font-medium text-fg">Task queue</h2>
          <span className="text-xs text-faint">{tasks.length} defined</span>
        </div>
        <ul className="space-y-2">
          {tasks.map((task) => (
            <li
              key={task.id}
              className="flex items-start gap-3 rounded-[var(--radius-md)] border border-line bg-raised p-3"
            >
              <button
                type="button"
                aria-label={task.enabled ? "Disable task" : "Enable task"}
                onClick={() => toggleTask(task.id)}
                className={cn(
                  "mt-0.5 size-11 shrink-0 rounded-[var(--radius-sm)] border text-xs font-medium",
                  task.enabled
                    ? "border-live/40 bg-live/10 text-live"
                    : "border-line bg-surface text-faint",
                )}
              >
                {task.kind}
              </button>
              <div className="min-w-0 flex-1">
                <p className="truncate font-mono text-xs text-faint">{task.id}</p>
                <p className="mt-1 text-sm text-fg">{task.message || "—"}</p>
                {task.kind === "wait" && (
                  <p className="mt-1 text-xs text-muted">
                    {task.durationMs}ms
                  </p>
                )}
              </div>
              <button
                type="button"
                aria-label="Remove task"
                onClick={() => removeTask(task.id)}
                className="mt-0.5 grid size-11 place-items-center rounded-[var(--radius-sm)] text-faint hover:bg-bg hover:text-danger"
              >
                <Trash2 className="size-4" />
              </button>
            </li>
          ))}
        </ul>

        <form
          className="mt-4 space-y-3 border-t border-line pt-4"
          onSubmit={(event) => {
            event.preventDefault();
            const trimmed = message.trim();
            if (!trimmed) return;
            addTask({
              kind,
              message: trimmed,
              durationMs: kind === "wait" ? 1500 : 0,
              enabled: true,
            });
            setMessage("");
          }}
        >
          <div className="flex flex-col gap-2 sm:flex-row">
            <select
              value={kind}
              onChange={(event) => setKind(event.target.value as TaskKind)}
              className="h-11 rounded-[var(--radius-sm)] border border-line bg-raised px-3 text-sm text-fg"
            >
              {TASK_KINDS.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>
            <input
              value={message}
              onChange={(event) => setMessage(event.target.value)}
              placeholder="Task message"
              className="h-11 min-w-0 flex-1 rounded-[var(--radius-sm)] border border-line bg-raised px-3 text-sm text-fg placeholder:text-faint"
            />
            <Button type="submit" size="md">
              <Plus className="size-4" />
              Add
            </Button>
          </div>
        </form>
      </section>

      <section className="rounded-[var(--radius-xl)] border border-line bg-surface p-4 sm:p-5">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="flex items-center gap-2 text-sm font-medium text-fg">
            <Terminal className="size-4 text-muted" />
            Loop log
          </h2>
          <Button variant="ghost" size="sm" onClick={clearLog}>
            Clear
          </Button>
        </div>
        {log.length === 0 ? (
          <p className="py-12 text-center text-sm text-muted">
            Start the loop to see tasks run here.
          </p>
        ) : (
          <ol className="max-h-[28rem] space-y-2 overflow-auto pr-1">
            {log.map((entry) => (
              <li
                key={entry.id}
                className="rounded-[var(--radius-sm)] border border-line bg-raised px-3 py-2"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono text-[11px] tracking-wide text-live uppercase">
                    {entry.kind}
                  </span>
                  <span className="font-mono text-[11px] tabular-nums text-faint">
                    {formatTime(entry.at)}
                  </span>
                </div>
                <p className="mt-1 text-sm leading-snug text-fg">{entry.text}</p>
              </li>
            ))}
          </ol>
        )}
      </section>
    </div>
  );
}

function ConfigPanel() {
  const config = useAssistant((s) => s.config);
  const configText = useAssistant((s) => s.configText);
  const configError = useAssistant((s) => s.configError);
  const setConfigText = useAssistant((s) => s.setConfigText);
  const applyConfigText = useAssistant((s) => s.applyConfigText);
  const resetConfig = useAssistant((s) => s.resetConfig);
  const setIntervalMs = useAssistant((s) => s.setIntervalMs);

  return (
    <section className="rounded-[var(--radius-xl)] border border-line bg-surface p-4 sm:p-5">
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-sm font-medium text-fg">Command file</h2>
          <p className="mt-1 text-sm text-muted">
            Same schema as the Android <span className="font-mono">config.json</span>.
            Kinds: log, wait, note.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="secondary" size="sm" onClick={applyConfigText}>
            Apply JSON
          </Button>
          <Button variant="ghost" size="sm" onClick={resetConfig}>
            <RotateCcw className="size-3.5" />
            Reset
          </Button>
        </div>
      </div>

      <label className="mb-4 flex items-center justify-between gap-3 text-sm">
        <span className="text-muted">Loop interval</span>
        <select
          value={config.intervalMs}
          onChange={(event) => setIntervalMs(Number(event.target.value))}
          className="h-11 rounded-[var(--radius-sm)] border border-line bg-raised px-3 text-sm text-fg"
        >
          <option value={4000}>4 seconds</option>
          <option value={8000}>8 seconds</option>
          <option value={15000}>15 seconds</option>
          <option value={30000}>30 seconds</option>
        </select>
      </label>

      <textarea
        value={configText}
        onChange={(event) => setConfigText(event.target.value)}
        spellCheck={false}
        className="min-h-72 w-full rounded-[var(--radius-md)] border border-line bg-bg p-4 font-mono text-sm leading-relaxed text-fg"
      />
      {configError ? (
        <p className="mt-3 text-sm text-danger">{configError}</p>
      ) : (
        <p className="mt-3 text-xs text-faint">
          Paste this JSON into the Android app assets file when you are ready
          to run on a device.
        </p>
      )}
    </section>
  );
}

function AndroidPanel() {
  return (
    <section className="space-y-4 rounded-[var(--radius-xl)] border border-line bg-surface p-4 sm:p-5">
      <div>
        <h2 className="font-display text-2xl font-medium tracking-[-0.03em]">
          Native companion
        </h2>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">
          This preview runs the same loop in the browser. The Kotlin project is
          a bare framework: one core file, one config file, internet +
          accessibility permissions declared, and a GitHub Action that builds a
          debug APK.
        </p>
      </div>

      <div className="rounded-[var(--radius-lg)] border border-line bg-raised p-4">
        <p className="text-xs font-medium tracking-[0.18em] text-warn uppercase">
          About the 502
        </p>
        <p className="mt-2 text-sm leading-relaxed text-fg">
          You do not need API keys. The Bad Gateway / Host Error was the preview
          relay being down — your browser and Cloudflare were fine, the app host
          was not. Steward never calls that host. Nothing to configure.
        </p>
      </div>

      <ol className="space-y-3 text-sm leading-relaxed text-muted">
        <li>
          <span className="font-medium text-fg">1. Core loop — </span>
          <span className="font-mono text-xs text-accent">Assistant.kt</span>
          {" "}reads <span className="font-mono text-xs text-accent">config.json</span>{" "}
          and walks enabled tasks on an interval.
        </li>
        <li>
          <span className="font-medium text-fg">2. Permissions — </span>
          INTERNET is declared for later network tasks. Accessibility is a
          connected stub so the service can stay alive; it does not read or
          tap other apps.
        </li>
        <li>
          <span className="font-medium text-fg">3. APK — </span>
          Push the repo to GitHub. The workflow{" "}
          <span className="font-mono text-xs text-accent">
            .github/workflows/build-debug-apk.yml
          </span>{" "}
          runs Gradle <span className="font-mono text-xs">assembleDebug</span>{" "}
          and uploads the APK.
        </li>
        <li>
          <span className="font-medium text-fg">4. On device — </span>
          Install the debug APK, open Steward, enable the accessibility service,
          then edit <span className="font-mono text-xs">config.json</span> to
          add work.
        </li>
      </ol>
    </section>
  );
}
